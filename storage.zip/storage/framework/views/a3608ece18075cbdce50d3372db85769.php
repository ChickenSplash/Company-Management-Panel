<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <a class="link" href="<?php echo e(route('employees.index')); ?>">Employees</a>
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 text-gray-900 dark:text-gray-100">
            <div class="table-wrapper mb-6">
                <table class="table">
                    <thead>
                        <tr>
                            <?php if (isset($component)) { $__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-employees-column','data' => ['label' => 'First Name','column' => 'first_name','sortBy' => $sortBy,'sortDirection' => $sortDirection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-employees-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'First Name','column' => 'first_name','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f)): ?>
<?php $attributes = $__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f; ?>
<?php unset($__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f)): ?>
<?php $component = $__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f; ?>
<?php unset($__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-employees-column','data' => ['label' => 'Last Name','column' => 'last_name','sortBy' => $sortBy,'sortDirection' => $sortDirection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-employees-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Last Name','column' => 'last_name','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f)): ?>
<?php $attributes = $__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f; ?>
<?php unset($__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f)): ?>
<?php $component = $__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f; ?>
<?php unset($__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-employees-column','data' => ['label' => 'Email','column' => 'email','sortBy' => $sortBy,'sortDirection' => $sortDirection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-employees-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','column' => 'email','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f)): ?>
<?php $attributes = $__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f; ?>
<?php unset($__attributesOriginal6a89ddff302bb0c090ae5b89f5fd682f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f)): ?>
<?php $component = $__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f; ?>
<?php unset($__componentOriginal6a89ddff302bb0c090ae5b89f5fd682f); ?>
<?php endif; ?>
                            <th>Number</th>
                            <th>Company</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="clickable-row" data-href="<?php echo e(route('employees.show', $employee->id)); ?>">
                                <td class="name-logo">
                                    <img class="logo" src="<?php echo e($employee->logo ? asset('images/' . $employee->logo) : asset('images/placeholder-profile-picture.jpg')); ?>" alt="Employee Logo">
                                    <?php echo e($employee->first_name); ?>

                                </td>
                                <td><?php echo e($employee->last_name); ?></td>
                                <td><?php echo e($employee->email); ?></td>
                                <td><?php echo e($employee->phone); ?></td>
                                <td><?php echo e($employee->company->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($employees->appends([ // tell the paginator to pass in the url parameters so it doesnt overwrite them
                'sortBy' => $sortBy, 
                'sortDirection' => $sortDirection
            ])->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH D:\Documents\Programming\Tasks\Company-Management-Panel\resources\views/employees/index.blade.php ENDPATH**/ ?>