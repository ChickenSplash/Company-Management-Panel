<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'column', 'sortBy', 'sortDirection', 'companyId']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'column', 'sortBy', 'sortDirection', 'companyId']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<th 
    class="clickable-row table-header" 
    data-href="<?php echo e(route('companies.show', array_merge(['id' => $companyId], request()->query(), ['sortBy' => $column, 'sortDirection' => ($sortBy === $column && $sortDirection === 'asc') ? 'desc' : 'asc']))); ?>"
>
    <?php echo e($label); ?>

    <?php if($sortBy === $column): ?>
        <?php echo e($sortDirection === 'asc' ? '↑' : '↓'); ?>

    <?php endif; ?>
</th><?php /**PATH D:\Documents\Programming\Tasks\Company-Management-Panel\resources\views/components/sortable-company-employees-column.blade.php ENDPATH**/ ?>