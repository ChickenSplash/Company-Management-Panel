<table class="table-auto w-full border-collapse border border-gray-300">
    <thead class="bg-gray-100">
        <tr>
            <th class="border border-gray-300 px-4 py-2">ID</th>
            <th class="border border-gray-300 px-4 py-2">Name</th>
            <th class="border border-gray-300 px-4 py-2">Email</th>
            <th class="border border-gray-300 px-4 py-2">Logo</th>
            <th class="border border-gray-300 px-4 py-2">Website</th>
            <th class="border border-gray-300 px-4 py-2">Created</th>
            <th class="border border-gray-300 px-4 py-2">Updated</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($company->id); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($company->name); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($company->email); ?></td>
                <td class="border border-gray-300 px-4 py-2">
                    <?php if($company->logo): ?>
                        <img src="<?php echo e(asset('storage/' . $company->logo)); ?>" alt="Logo" class="h-10">
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
                <td class="border border-gray-300 px-4 py-2">
                    <a href="<?php echo e($company->website); ?>" target="_blank" class="text-blue-500 underline">
                        <?php echo e($company->website); ?>

                    </a>
                </td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($company->created_at); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($company->updated_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\Documents\Programming\Tasks\Company-Management-Panel\resources\views/components/company-table.blade.php ENDPATH**/ ?>