<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <a class="link" href="<?php echo e(route('companies.index')); ?>">Companies</a>
        </h2>
     <?php $__env->endSlot(); ?>
    
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 text-gray-900 dark:text-gray-100">
            <div class="table-wrapper mb-6">
                <table class="table">
                    <thead>
                        <tr>
                            <?php if (isset($component)) { $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-companies-column','data' => ['label' => 'Name','column' => 'name','sortBy' => $sortBy,'sortDirection' => $sortDirection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-companies-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Name','column' => 'name','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $attributes = $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $component = $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-companies-column','data' => ['label' => 'Employees','column' => 'employees_count','sortBy' => $sortBy,'sortDirection' => $sortDirection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-companies-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Employees','column' => 'employees_count','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $attributes = $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $component = $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-companies-column','data' => ['label' => 'Email','column' => 'email','sortBy' => $sortBy,'sortDirection' => $sortDirection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-companies-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','column' => 'email','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $attributes = $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $component = $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-companies-column','data' => ['label' => 'Website','column' => 'website','sortBy' => $sortBy,'sortDirection' => $sortDirection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-companies-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Website','column' => 'website','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $attributes = $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $component = $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-companies-column','data' => ['label' => 'Last Updated','column' => 'updated_at','sortBy' => $sortBy,'sortDirection' => $sortDirection]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-companies-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Last Updated','column' => 'updated_at','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $attributes = $__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__attributesOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98)): ?>
<?php $component = $__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98; ?>
<?php unset($__componentOriginal6a3a4e9fd0e9842559b64b33889c9b98); ?>
<?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="clickable-row" data-href="<?php echo e(route('companies.show', $company->id)); ?>">
                                <td class="name-logo">
                                    <img class="logo" src="<?php echo e($company->logo ? asset('images/' . $company->logo) : asset('images/placeholder-logo.jpg')); ?>" alt="Company Logo">
                                    <span><?php echo e($company->name); ?></span>
                                </td>
                                <td class="numbered-cell"><?php echo e($company->employees_count); ?></td>
                                <td><?php echo e($company->email); ?></td>
                                <td><?php echo e(Str::replaceFirst('www.', '', parse_url($company->website, PHP_URL_HOST))); ?></td>
                                <td><?php echo e($company->updated_at->format('jS F Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($companies->appends([ // tell the paginator to pass in the url parameters so it doesnt overwrite them
                'sortBy' => $sortBy, 
                'sortDirection' => $sortDirection
            ])->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Documents\Programming\Tasks\Company-Management-Panel\resources\views/companies/index.blade.php ENDPATH**/ ?>