<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <a class="link" href="<?php echo e(route('companies.index')); ?>">Companies</a>
            / <a class="link" href="<?php echo e(route('companies.show', $company->id)); ?>"><?php echo e($company->name); ?></a> 
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="p-6 mb-6 text-gray-900 dark:text-gray-100 bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg">
                <div class="company">
                    <h3 class="name"><?php echo e($company->name); ?></h3>
                    <div class="card">
                        <img class="logo" src="<?php echo e($company->logo ? asset('images/' . $company->logo) : asset('images/placeholder-logo.jpg')); ?>" alt="Company Logo">
                        <div class="details">
                            <?php if($company->email): ?>
                                <p><a class="link" href="mailto:<?php echo e($company->email); ?>" target="_blank"><?php echo e($company->email); ?></a></p>
                            <?php endif; ?>
                            <?php if($company->website): ?>
                                <p><a class="link" href="<?php echo e($company->website); ?>" target="_blank">Visit Website</strong></a> <span class="link-text">(<?php echo e(Str::limit($company->website, 50)); ?>)</span></p>
                            <?php endif; ?>
                            <?php if($company->employees()->count()): ?>
                                <p>Total Employees: <?php echo e($company->employees()->count()); ?></p>
                            <?php else: ?>
                                <p>This company has no employees.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="dates">
                        <p>Created on <?php echo e($company->created_at->format('jS F Y')); ?></p>
                        <?php if($company->created_at != $company->updated_at): ?>
                            <p>Updated on <?php echo e($company->updated_at->format('jS F Y')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="buttons">
                        <?php if (isset($component)) { $__componentOriginal81e9d2ae268c88e11768f6576eddadc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-link-button','data' => ['href' => ''.e(route('companies.edit', $company->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('companies.edit', $company->id)).'']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $attributes = $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $component = $__componentOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal81e9d2ae268c88e11768f6576eddadc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-link-button','data' => ['href' => ''.e(route('employees.create', $company->id)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('employees.create', $company->id)).'']); ?>Add Employee <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $attributes = $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $component = $__componentOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal81e9d2ae268c88e11768f6576eddadc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-link-button','data' => ['href' => ''.e(route('companies.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('companies.index')).'']); ?>Back <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $attributes = $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $component = $__componentOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if($company->employees()->count()): ?>
                <div class="table-wrapper text-gray-100 mb-6">
                    <table class="table">
                        <thead>
                            <tr>
                                <?php if (isset($component)) { $__componentOriginal8641d3e8021174f208a76a0cd7524d0b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8641d3e8021174f208a76a0cd7524d0b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-company-employees-column','data' => ['label' => 'ID','column' => 'id','sortBy' => $sortBy,'sortDirection' => $sortDirection,'companyId' => $company->id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-company-employees-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'ID','column' => 'id','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection),'companyId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8641d3e8021174f208a76a0cd7524d0b)): ?>
<?php $attributes = $__attributesOriginal8641d3e8021174f208a76a0cd7524d0b; ?>
<?php unset($__attributesOriginal8641d3e8021174f208a76a0cd7524d0b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8641d3e8021174f208a76a0cd7524d0b)): ?>
<?php $component = $__componentOriginal8641d3e8021174f208a76a0cd7524d0b; ?>
<?php unset($__componentOriginal8641d3e8021174f208a76a0cd7524d0b); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal8641d3e8021174f208a76a0cd7524d0b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8641d3e8021174f208a76a0cd7524d0b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-company-employees-column','data' => ['label' => 'Name','column' => 'last_name','sortBy' => $sortBy,'sortDirection' => $sortDirection,'companyId' => $company->id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-company-employees-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Name','column' => 'last_name','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection),'companyId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8641d3e8021174f208a76a0cd7524d0b)): ?>
<?php $attributes = $__attributesOriginal8641d3e8021174f208a76a0cd7524d0b; ?>
<?php unset($__attributesOriginal8641d3e8021174f208a76a0cd7524d0b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8641d3e8021174f208a76a0cd7524d0b)): ?>
<?php $component = $__componentOriginal8641d3e8021174f208a76a0cd7524d0b; ?>
<?php unset($__componentOriginal8641d3e8021174f208a76a0cd7524d0b); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal8641d3e8021174f208a76a0cd7524d0b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8641d3e8021174f208a76a0cd7524d0b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-company-employees-column','data' => ['label' => 'Email','column' => 'email','sortBy' => $sortBy,'sortDirection' => $sortDirection,'companyId' => $company->id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-company-employees-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email','column' => 'email','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDirection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDirection),'companyId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8641d3e8021174f208a76a0cd7524d0b)): ?>
<?php $attributes = $__attributesOriginal8641d3e8021174f208a76a0cd7524d0b; ?>
<?php unset($__attributesOriginal8641d3e8021174f208a76a0cd7524d0b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8641d3e8021174f208a76a0cd7524d0b)): ?>
<?php $component = $__componentOriginal8641d3e8021174f208a76a0cd7524d0b; ?>
<?php unset($__componentOriginal8641d3e8021174f208a76a0cd7524d0b); ?>
<?php endif; ?>
                                <th>Phone</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sortedEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="clickable-row" data-href="<?php echo e(route('employees.show', $employee->id)); ?>">
                                    <td><?php echo e($employee->id); ?></td>
                                    <td class="name-logo">
                                        <img class="logo" src="<?php echo e($employee->logo ? asset('images/' . $employee->logo) : asset('images/placeholder-profile-picture.jpg')); ?>" alt="Employee Logo">
                                        <?php echo e($employee->first_name . ' ' . $employee->last_name); ?>

                                    </td>
                                    <td><?php echo e($employee->email); ?></td>
                                    <td><?php echo e($employee->phone); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($sortedEmployees->appends([ // tell the paginator to pass in the url parameters so it doesnt overwrite them
                    'sortBy' => $sortBy, 
                    'sortDirection' => $sortDirection
                ])->links()); ?>

            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Documents\Programming\Tasks\Company-Management-Panel\resources\views/companies/show.blade.php ENDPATH**/ ?>