<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <a class="link" href="<?php echo e(route('employees.index')); ?>">Employees</a>
        </h2>
     <?php $__env->endSlot(); ?>
    
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <ul class="index-list">
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal3b9e1d6a7a4f4d01c9fa0330c2d845be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b9e1d6a7a4f4d01c9fa0330c2d845be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.employee-list-item','data' => ['employee' => $employee]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('employee-list-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['employee' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($employee)]); ?>
                        <div class="card">
                            <img class="logo" src="<?php echo e($employee->logo ? asset('storage/' . $employee->logo) : asset('images/placeholder-profile-picture.jpg')); ?>" alt="Employee Logo">
                            <div class="details">
                                <h3><?php echo e($employee->first_name . ' ' . $employee->last_name); ?></h3>
                                <p class="minor-details">Company: <?php echo e($employee->company->name); ?></p>
                                <?php if($employee->created_at != $employee->updated_at): ?>
                                    <p class="minor-details">Updated on <?php echo e($employee->updated_at->format('jS F Y')); ?></p>
                                <?php else: ?>
                                    <p class="minor-details">Created on <?php echo e($employee->created_at->format('jS F Y')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b9e1d6a7a4f4d01c9fa0330c2d845be)): ?>
<?php $attributes = $__attributesOriginal3b9e1d6a7a4f4d01c9fa0330c2d845be; ?>
<?php unset($__attributesOriginal3b9e1d6a7a4f4d01c9fa0330c2d845be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b9e1d6a7a4f4d01c9fa0330c2d845be)): ?>
<?php $component = $__componentOriginal3b9e1d6a7a4f4d01c9fa0330c2d845be; ?>
<?php unset($__componentOriginal3b9e1d6a7a4f4d01c9fa0330c2d845be); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php echo e($employees->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH D:\Documents\Programming\Tasks\Companies-Dashboard-3\resources\views/employees/index.blade.php ENDPATH**/ ?>