## Recommendation to run locally:

- Run Apache using [XAMPP](https://www.apachefriends.org/download.html).
- Download and unzip this repo, set the Apache config file to run the server on [public](public).
- [.env.example](.env.example) is to be renamed to `.env`.
- run `npm run dev` in the command prompt in the directory of this project.