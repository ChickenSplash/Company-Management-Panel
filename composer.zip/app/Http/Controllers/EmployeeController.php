<?php

namespace App\Http\Controllers;

use App\Http\Requests\EmployeeRequest;
use App\Models\Company;
use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index() {
        
        $employees = Employee::paginate(10);

        return view('employees.index', compact('employees'));
    }

    public function show($id) { 

        $employee = Employee::with('company')->findOrFail($id);

        return view('employees.show', compact('employee'));
    }

    public function edit($id) 
    {
        $employee = Employee::findOrFail($id);
        $companies = Company::all();

        return view('employees.edit', compact('employee', 'companies'));
    }

    public function update(EmployeeRequest $request, $id)
    {
        $validated = $request->validated();

        $employee = Employee::findOrFail($id);
        $employee->update($validated);

        return redirect()->route('employees.show', $id);
    }

    public function create($currentCompanyId = null)
    {
        $companies = Company::all();
        return view('employees.create', compact('companies', 'currentCompanyId'));
    }

    public function store(EmployeeRequest $request)
    {
        $validated = $request->validated();

        $employee = Employee::create($validated);

        return redirect()->route('employees.show', $employee->id);
    }    

    public function destroy($id)
    {
        $employee = Employee::findOrFail($id);
        $employee->delete();

        return redirect()->route('employees.index');
    }
}
